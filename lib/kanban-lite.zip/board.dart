import 'package:kanban_lite/add_column_button.dart';

import 'column.dart';

class Board {
  final List<Column> columns;
  static final int maxColumns = 5;
  bool canAddColumns = true;
  final AddColumnButton addColumnButton;
  Board(this.columns) : addColumnButton = AddColumnButton() {
    columns[columns.length - 1].setIsLastColumn(true);
    columns[0].isFirstColumn = true;
  }
  void addColumn(Column c) {
    if (columns.length < maxColumns) {
      columns.last.setIsLastColumn(false);
      columns.add(c);
      c.setIsLastColumn(true);
      canAddColumns = (columns.length < maxColumns);
    }
  }

  void removeColumn(Column c) {
    columns.remove(c);
    canAddColumns = (columns.length < maxColumns);
    columns.last.setIsLastColumn(true);
  }
}
