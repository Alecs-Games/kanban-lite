import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import './board_painter.dart';
import './board.dart';
import './column.dart' as cl;
import 'firebase_options.dart';
import './card.dart' as ca;
import 'prompt.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MaterialApp(home: MainApp()));
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  final Board board = Board([
    cl.Column([], "Step 1"),
    cl.Column([], "Step 2"),
    cl.Column([], "Step 3"),
  ]);

  ca.Card? heldCard;
  Offset dragOffset = Offset(0, 0);
  OverlayEntry? cardRename;
  bool interfaceEnabled = true;

  @override
  void initState() {
    super.initState();

    board.columns[0].addCard(ca.Card("test1"));
    board.columns[0].addCard(ca.Card("test2"));
    board.columns[2].addCard(ca.Card("test3"));
  }

  OverlayEntry? promptOverlay;

  void showCenteredPrompt({
    required String label,
    required String initialText,
    required void Function(String) onSubmitted,
  }) {
    final overlay = Overlay.of(context);
    interfaceEnabled = false;
    promptOverlay = OverlayEntry(
      builder:
          (context) => Material(
            color: Colors.transparent,
            child: Prompt(
              label: label,
              initialText: initialText,
              onSubmitted: (value) {
                onSubmitted(value);
                interfaceEnabled = true;
                promptOverlay?.remove();
                promptOverlay = null;
              },
            ),
          ),
    );

    overlay.insert(promptOverlay!);
  }

  void onTouch(Offset position) {
    if (board.canAddColumns && board.addColumnButton.rect.contains(position)) {
      showCenteredPrompt(
        label: "Add Column",
        initialText: "Step ${board.columns.length + 1}",
        onSubmitted: (value) {
          setState(() {
            board.addColumn(cl.Column([], value));
          });
        },
      );
    }
    for (cl.Column column in board.columns) {
      if (column.namePlate.contains(position)) {
        showCenteredPrompt(
          label: "Rename Column",
          initialText: column.name,
          onSubmitted: (value) {
            setState(() {
              column.name = value;
            });
          },
        );
      }
      for (ca.Card card in column.cards) {
        if (card.handle.contains(position)) {
          //handle clicked, start dragging card
          setState(() {
            if (heldCard != null) {
              heldCard!.handle.isHeld = false;
            }
            dragOffset = card.offset - position;
            card.handle.isHeld = true;
            heldCard = card;
          });
          return;
        } else {
          //card clicked outside of handle
          //check first if delete button was clicked
          if (card.deletable && card.deleteButton.contains(position)) {
            //delete card
            if (card.column != null) {
              setState(() {
                card.column!.removeCard(card);
              });
            }
          } else {
            //name is clicked, rename card
            Rect cardRect = (card.offset & card.size);
            if (cardRect.contains(position)) {
              showCenteredPrompt(
                label: "Rename Card",
                initialText: card.text,
                onSubmitted: (value) {
                  setState(() {
                    card.text = value;
                  });
                },
              );
            }
          }
        }
      }
      if (column.bottomButton.contains(position)) {
        //bottom button is clicked. Add new card if this is the first column, remove column otherwise
        if (column.isFirstColumn) {
          showCenteredPrompt(
            label: "Add Card",
            initialText: "",
            onSubmitted: (value) {
              setState(() {
                column.addCard(ca.Card(value));
              });
            },
          );
        } else {
          setState(() {
            board.removeColumn(column);
          });
        }
      }
    }
  }

  void onRelease(Offset position) {
    if (heldCard != null) {
      setState(() {
        cl.Column? dropColumn = hoveredColumn(position);
        if (dropColumn != null) {
          print(dropColumn);
          if (heldCard!.column != null) {
            heldCard!.column!.removeCard(heldCard!);
          }
          dropColumn.addCard(heldCard!);
        }
        heldCard!.handle.isHeld = false;
        heldCard = null;
      });
    }
  }

  void onMove(Offset position) {
    if (heldCard != null) {
      setState(() {
        heldCard!.offset = position + dragOffset;
        heldCard!.handle.offset = position;
      });
    }
  }

  cl.Column? hoveredColumn(Offset position) {
    for (int i = 0; i < board.columns.length; i++) {
      final cl.Column currColumn = board.columns[i];
      final Rect columnRect = (currColumn.offset & currColumn.size);
      if (columnRect.contains(position)) {
        return currColumn;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final double boardWidth = constraints.maxWidth * 0.95;
        final double boardHeight = constraints.maxHeight * 0.95;

        return Center(
          child: IgnorePointer(
            ignoring: !interfaceEnabled,
            child: Listener(
              onPointerDown: (details) => onTouch(details.localPosition),
              onPointerUp: (details) => onRelease(details.localPosition),
              onPointerMove: (details) => onMove(details.localPosition),
              child: SizedBox(
                width: boardWidth,
                height: boardHeight,
                child: CustomPaint(painter: BoardPainter(board)),
              ),
            ),
          ),
        );
      },
    );
  }
}
