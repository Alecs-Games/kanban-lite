import './card.dart' as ca;
import './card_painter.dart';
import 'package:flutter/widgets.dart';

class Column {
  static const int capacity = 5;
  List<ca.Card> cards;
  late Size size;
  late Offset offset;
  bool _isLastColumn = false;
  late Rect bottomButton;
  late Rect namePlate;
  bool isFirstColumn = false;
  String name;

  Column(this.cards, this.name);

  void addCard(ca.Card card) {
    if (cards.length < capacity) {
      cards.add(card);
      card.column = this;
      card.deletable = _isLastColumn;
    }
  }

  void removeCard(ca.Card card) {
    cards.remove(card);
  }

  void setIsLastColumn(bool status) {
    _isLastColumn = status;
    for (ca.Card c in cards) {
      c.deletable = _isLastColumn;
    }
  }
}
