import 'package:flutter/widgets.dart';
import 'handle.dart';
import 'column.dart' as cl;

class Card {
  late String text;
  late Size size;
  late Offset offset;
  late Handle handle;
  late Rect deleteButton;
  cl.Column? column;
  bool deletable = false;

  Card(this.text) : handle = Handle();
}
