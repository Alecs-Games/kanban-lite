import 'package:flutter/widgets.dart';

class AddColumnButton {
  late Rect rect;
  AddColumnButton();
}
